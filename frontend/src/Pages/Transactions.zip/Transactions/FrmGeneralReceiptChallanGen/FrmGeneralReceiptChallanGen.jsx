import React, { useState, useEffect } from "react";
import Header from "../../../HOC/Header/Header";
import Navbar from "../../../HOC/Navbar/Navbar";
import { useNavigate } from "react-router-dom";
import HeaderLabel from "../../../Components/HeaderLabel/HeaderLabel";
import SaveButton from "../../../Components/Buttons_save/Savebutton";
import InputField from "../../../Components/InputField/InputField";
import { useLanguage } from "../../../Context/LanguageProvider";
import { useAuth } from "../../../Context/AuthContext";
import { Formik, Form, Field, ErrorMessage } from "formik";
import Label from "../../../Components/Label/Label";
import CalendarIcon from "../../../Components/Calendar/CalendarIcon";
import { ValidationSchemas } from "../../../HOC/Validation/Validation";

import apiService from "../../../../apiService"; 


function FrmGeneralReceiptChallanGen() {
  const { translate } = useLanguage();
  const { user } = useAuth();
  const UlbId = user?.ulbId;
  const userId = user?.userId;
  const navigate = useNavigate();
  const [fromDate, setFromDate] = useState(null);
  const [ToDate, setToDate] = useState(null);
  const [ChallanDate, setChallanDate] = useState(null);
  const [paymentModes, setPaymentModes] = useState([]);
  const [wards, setWards] = useState([]);
  const validationSchema =
    ValidationSchemas(translate).FrmGeneralReceiptChallanGen;

  const formatDate = (dateObj) => {
    if (!dateObj) return "";
    const date = new Date(dateObj);
    const day = String(date.getDate()).padStart(2, "0");
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const year = date.getFullYear();
    return `${day}-${month}-${year}`;
  };

  const [initialValues, setInitialValues] = useState({
    ChallanDate: "",
    FromDate: "",
    ToDate: null,
    Prabhag: "", // Added fields to initialValues for Formik
    PaymentMode: "",
  });

  useEffect(() => {
    if (UlbId) {
      // Function to fetch data
      const fetchData = async () => {
        // 2. Replace raw fetch with apiService for Payment Modes
        try {
          const paymentModesResponse = await apiService.post("getRecModeConfig", { ulbId: UlbId });
          const paymentModesData = paymentModesResponse.data;
          
          if (Array.isArray(paymentModesData?.data)) {
            const formattedOptions = paymentModesData.data.map((mode) => ({
              label: mode.RECMODENAME,
              value: mode.RECMODEID,
            }));
            setPaymentModes(formattedOptions);
          }
        } catch (err) {
          console.error("Error fetching payment modes:", err);
        }

        // 2. Replace raw fetch with apiService for Ward Names
        try {
          const wardsResponse = await apiService.post("getWardNamesAndIdsByUlbId", { ulbId: UlbId });
          const wardsData = wardsResponse.data;

          if (Array.isArray(wardsData?.data)) {
            const wardOptions = wardsData.data.map((ward) => ({
              label: ward.WARDNAME,
              value: ward.WARDID,
            }));
            setWards(wardOptions);
          }
        } catch (err) {
          console.error("Error fetching wards:", err);
        }
      };

      fetchData();
    }
  }, [UlbId]); // Dependency array remains UlbId

  return (
    <div>
      <Header />
      <Navbar />

      <div className="container">
        <HeaderLabel
          className="headerlabel mt-4"
          text={translate("General Receipt Challan Generation")}
        />
        <hr />

        <Formik
          initialValues={initialValues}
          validationSchema={validationSchema}
          onSubmit={async (values, { setSubmitting }) => {
            try {
              const payload = {
                username: userId,
                chalanDate: formatDate(values.ChallanDate),
                receiptFromDate: formatDate(values.FromDate),
                receiptToDate: formatDate(values.ToDate),
                prabhagId: values.Prabhag,
                payMode: values.PaymentMode,
                orgId: UlbId,
              };

              // 3. Replace raw fetch with apiService for form submission
              const response = await apiService.post(
                "aomk_genrct_chalannumber_gen", // Endpoint
                payload // Data
              );

              // Assuming apiService returns the result data directly or nested in 'data'
              const result = response.data || response; // Adjusted to handle common apiService return formats

              if (result.success) {
                alert("Challan generated successfully!");
              } else {
                // Fallback message check
                alert(`${result.message || "Challan generation failed."}`);
              }
            } catch (error) {
              console.error("Error submitting form:", error);
              // Check if the error is a standard API error with a response message
              const errorMessage = error.response?.data?.message || "An unexpected error occurred.";
              alert(errorMessage);
            } finally {
              setSubmitting(false);
            }
          }}
        >
          {({ setFieldValue }) => (
            <Form>
              <div className="row mb-3 align-items-center mt-4">
                <div className="col-md-4">
                  <div className="mb-2">
                    <Label text={`${translate("Challan Date")} :`} required />
                  </div>
                  <CalendarIcon
                    name="ChallanDate"
                    selectedDate={ChallanDate}
                    setSelectedDate={(date) => {
                      setChallanDate(date);
                      setFieldValue("ChallanDate", date);
                    }}
                    placeholder="DD/MM/YYYY"
                  />
                  <ErrorMessage
                    name="ChallanDate"
                    component="div"
                    className="text-danger"
                  />
                </div>
                <div className="col-md-4">
                  <div className="mb-2">
                    <Label text={`${translate("From Date")} :`} required />
                  </div>
                  <CalendarIcon
                    name="FromDate"
                    selectedDate={fromDate}
                    setSelectedDate={(date) => {
                      setFromDate(date);
                      setFieldValue("FromDate", date);
                    }}
                    placeholder="DD/MM/YYYY"
                  />
                  <ErrorMessage
                    name="FromDate"
                    component="div"
                    className="text-danger"
                  />
                </div>
                <div className="col-md-4">
                  <div className="mb-2">
                    <Label text={`${translate("To Date")} :`} required />
                  </div>
                  <CalendarIcon
                    name="ToDate"
                    selectedDate={ToDate}
                    setSelectedDate={(date) => {
                      setToDate(date);
                      setFieldValue("ToDate", date);
                    }}
                    placeholder="DD/MM/YYYY"
                  />
                  <ErrorMessage
                    name="ToDate"
                    component="div"
                    className="text-danger"
                  />
                </div>
              </div>

              <div className="row mb-3">
                <div className="col-md-4">
                  <div className="mb-2">
                    <Label text={`${translate("Prabhag")} :`} required />
                  </div>
                  <Field
                    name="Prabhag"
                    component={InputField}
                    className="form-control"
                    type="dropdown"
                    options={wards}
                  />
                  <ErrorMessage
                    name="Prabhag"
                    component="div"
                    className="text-danger"
                  />
                </div>
                <div className="col-md-4">
                  <div className="mb-2">
                    <Label text={`${translate("Payment Mode")} :`} required />
                  </div>
                  <Field
                    name="PaymentMode"
                    component={InputField}
                    className="form-control"
                    type="dropdown"
                    options={paymentModes}
                  />
                  <ErrorMessage
                    name="PaymentMode"
                    component="div"
                    className="text-danger"
                  />
                </div>
              </div>

              <div className="d-flex justify-content-center flex-direction-row gap-4 mt-5">
                <SaveButton type="submit" text={translate("Submit")} />
                <SaveButton
                  type="button"
                  text={translate("Back")}
                  onClick={() => navigate("/HomePage/Dashboard.aspx")}
                />
              </div>
            </Form>
          )}
        </Formik>
      </div>
    </div>
  );
}

export default FrmGeneralReceiptChallanGen;